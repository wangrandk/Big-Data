# Rutetrafik: Pålidelighed 
Til analyseformål vedr. Pålidelighed og klumpning på tjekpunktsniveau.

## Forudsættende services
Følgende understøttende services er nødvendige for at løsningen kan udvikles og driftes. Disse dokumenteres særskilt.

- Data Warehouse Udviklings- og Produktions-miljø jf. [1], herunder særligt:
  - SQL Server Database Services (v. 13.0+)
  - SQL Server Integration Services (v. 13.0+)
  - SQL Server Analysis Services (v. 13.0+)

## Dokumentation
Der henvises til *Begrebsmodel for Rutetrafik* [2] for general forklaring af brugte termer. For yderligere information vedr. design, implementering m.v. henvises til *RT_DrivingReliability_DataAnalysisAndReporting* [3].

Analyser kan foretages på følgende dimensioner/niveauer:
- Dato
- Dagstype
- Operatør
- Linje / Retning / Turmønster / Produktgruppe
- Kommune /Takstområde
- Tjekpunktsektion
- Pålidelighedstype
- Garage

## Referencer
[1]: Niklas Christoffer Petersen, IT, Trafik og Data, *Movia Data Warehouse og BI: Arkitektur- og Designkonventioner*, Movia

[2]: Niklas Christoffer Petersen, IT, Trafik og Data, *Rutetrafik: Begrebsmodel*, Movia

[3]: Troels Skjellerup Nielsen, IT, Trafik og Data, *RT_DrivingReliability_DataAnalysisAndReporting*, Movia


